var toplam=0;    

var adanaKebapFiyat = 630;
    
var lahmacunFiyat = 240;
    
var sutlacFiyat = 100;
    
var toplam= adanaKebapFiyat+lahmacunFiyat+sutlacFiyat

console.log(toplam)